/*
 * SO2 lab-02 - task 4 - add.c
 */

int add(int a, int b)
{
	return a + b;
}
